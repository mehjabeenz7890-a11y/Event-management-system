# Event Registration System (Django + Django REST Framework)

Users sign up, browse events, register, and view/cancel their registrations.
Organizers (staff users) manage events through the API or the Django admin panel.

## Setup
```bash
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
python manage.py migrate
python manage.py seed_demo        # optional: admin/admin12345 + 3 sample events
python manage.py runserver
```
- API root (browsable): http://127.0.0.1:8000/api/
- Admin panel: http://127.0.0.1:8000/admin/ (create your own with `python manage.py createsuperuser`)
- Tests: `python manage.py test`

### PostgreSQL (optional)
`pip install "psycopg[binary]"`, then set `POSTGRES_DB`, `POSTGRES_USER`, `POSTGRES_PASSWORD`,
`POSTGRES_HOST`, `POSTGRES_PORT` before running `migrate`. SQLite is used when `POSTGRES_DB` is unset.

## Data model
- **Event**: title, description, location, start_time, end_time, capacity, organizer (FK User), is_published
- **Registration**: user (FK), event (FK), status (`registered`/`cancelled`), phone, notes, created_at, cancelled_at.
  Unique per (user, event); cancelling keeps the row, and re-registering reactivates it.

## API
Authenticate with `Authorization: Token <token>`.

| Method | Route | Auth | Description |
|---|---|---|---|
| POST | `/api/auth/signup/` | none | `{username, email?, password}` -> user + token |
| POST | `/api/auth/login/` | none | `{username, password}` -> `{token}` |
| GET | `/api/events/` | none | List events. `?upcoming=true`, `?search=text`, `?page=2` |
| GET | `/api/events/<id>/` | none | Details with `seats_left`, `registered_count`, `is_registered` |
| POST | `/api/events/<id>/register/` | user | Registration form `{phone?, notes?}` |
| GET | `/api/registrations/` | user | My registrations. `?status=registered` |
| GET | `/api/registrations/<id>/` | user | One of my registrations |
| POST | `/api/registrations/<id>/cancel/` | user | Cancel (also `DELETE /api/registrations/<id>/`) |
| POST | `/api/events/` | staff | Create event (you become the organizer) |
| PUT/PATCH/DELETE | `/api/events/<id>/` | event organizer | Edit or delete |
| GET | `/api/events/<id>/registrations/` | event organizer | Attendee list |

### Example
```bash
curl -X POST localhost:8000/api/auth/signup/ -H "Content-Type: application/json" \
  -d '{"username":"alice","password":"Str0ng-pass-99"}'

curl -X POST localhost:8000/api/events/1/register/ \
  -H "Authorization: Token <token>" -H "Content-Type: application/json" \
  -d '{"phone":"555-0100","notes":"Vegetarian"}'

curl -H "Authorization: Token <token>" localhost:8000/api/registrations/
curl -X POST -H "Authorization: Token <token>" localhost:8000/api/registrations/1/cancel/
```

## Rules enforced
- One active registration per user per event; capacity can't be exceeded (checked in a transaction)
- No registering for unpublished events or events that already started
- Users only see and cancel their own registrations
- Only staff can create events; only an event's organizer can edit it or see attendees
- Admin panel: manage events/registrations inline, filter/search, export registrations to CSV
