from datetime import timedelta

from django.contrib.auth import get_user_model
from django.utils import timezone
from rest_framework.test import APITestCase

from .models import Event

User = get_user_model()


def make_event(organizer, capacity=2, days=5, **kw):
    now = timezone.now()
    return Event.objects.create(
        title=kw.pop("title", "Test Event"), location="Hall", capacity=capacity, organizer=organizer,
        start_time=now + timedelta(days=days), end_time=now + timedelta(days=days, hours=2), **kw,
    )


class BaseCase(APITestCase):
    def setUp(self):
        self.organizer = User.objects.create_user("org", password="pw-12345-x", is_staff=True)
        self.alice = User.objects.create_user("alice", password="pw-12345-x")
        self.bob = User.objects.create_user("bob", password="pw-12345-x")
        self.event = make_event(self.organizer)


class AuthTests(APITestCase):
    def test_signup_and_login(self):
        r = self.client.post("/api/auth/signup/", {"username": "new", "password": "Str0ng-pass-99"})
        self.assertEqual(r.status_code, 201)
        self.assertIn("token", r.data)
        r = self.client.post("/api/auth/login/", {"username": "new", "password": "Str0ng-pass-99"})
        self.assertEqual(r.status_code, 200)

    def test_weak_password_rejected(self):
        r = self.client.post("/api/auth/signup/", {"username": "x", "password": "123"})
        self.assertEqual(r.status_code, 400)


class EventTests(BaseCase):
    def test_public_list_and_detail(self):
        self.assertEqual(self.client.get("/api/events/").data["count"], 1)
        r = self.client.get(f"/api/events/{self.event.id}/")
        self.assertEqual(r.data["seats_left"], 2)
        self.assertFalse(r.data["is_registered"])

    def test_unpublished_hidden(self):
        make_event(self.organizer, title="Secret", is_published=False)
        self.assertEqual(self.client.get("/api/events/").data["count"], 1)

    def test_only_staff_can_create(self):
        payload = {"title": "X", "location": "Y", "capacity": 5,
                   "start_time": (timezone.now() + timedelta(days=1)).isoformat(),
                   "end_time": (timezone.now() + timedelta(days=1, hours=1)).isoformat()}
        self.client.force_authenticate(self.alice)
        self.assertEqual(self.client.post("/api/events/", payload).status_code, 403)
        self.client.force_authenticate(self.organizer)
        r = self.client.post("/api/events/", payload)
        self.assertEqual(r.status_code, 201)
        self.assertEqual(r.data["organizer"], "org")

    def test_end_before_start_rejected(self):
        self.client.force_authenticate(self.organizer)
        now = timezone.now()
        r = self.client.post("/api/events/", {"title": "X", "location": "Y", "capacity": 5,
                                              "start_time": (now + timedelta(days=2)).isoformat(),
                                              "end_time": (now + timedelta(days=1)).isoformat()})
        self.assertEqual(r.status_code, 400)


class RegistrationTests(BaseCase):
    def url(self):
        return f"/api/events/{self.event.id}/register/"

    def test_requires_login(self):
        self.assertEqual(self.client.post(self.url()).status_code, 401)

    def test_register_and_duplicate(self):
        self.client.force_authenticate(self.alice)
        r = self.client.post(self.url(), {"phone": "123", "notes": "vegan"})
        self.assertEqual(r.status_code, 201)
        self.assertEqual(r.data["status"], "registered")
        self.assertEqual(self.client.post(self.url()).status_code, 400)
        self.assertTrue(self.client.get(f"/api/events/{self.event.id}/").data["is_registered"])

    def test_capacity_enforced(self):
        carol = User.objects.create_user("carol", password="pw-12345-x")
        for u in (self.alice, self.bob):
            self.client.force_authenticate(u)
            self.assertEqual(self.client.post(self.url()).status_code, 201)
        self.client.force_authenticate(carol)
        r = self.client.post(self.url())
        self.assertEqual(r.status_code, 400)
        self.assertIn("full", str(r.data).lower())

    def test_cancel_frees_seat_and_allows_reregister(self):
        self.client.force_authenticate(self.alice)
        reg_id = self.client.post(self.url()).data["id"]
        r = self.client.post(f"/api/registrations/{reg_id}/cancel/")
        self.assertEqual(r.data["status"], "cancelled")
        self.assertEqual(self.client.get(f"/api/events/{self.event.id}/").data["seats_left"], 2)
        self.assertEqual(self.client.post(f"/api/registrations/{reg_id}/cancel/").status_code, 400)
        self.assertEqual(self.client.post(self.url()).status_code, 201)

    def test_delete_is_cancel(self):
        self.client.force_authenticate(self.alice)
        reg_id = self.client.post(self.url()).data["id"]
        r = self.client.delete(f"/api/registrations/{reg_id}/")
        self.assertEqual(r.data["status"], "cancelled")

    def test_users_only_see_own_registrations(self):
        self.client.force_authenticate(self.alice)
        reg_id = self.client.post(self.url()).data["id"]
        self.assertEqual(self.client.get("/api/registrations/").data["count"], 1)
        self.client.force_authenticate(self.bob)
        self.assertEqual(self.client.get("/api/registrations/").data["count"], 0)
        self.assertEqual(self.client.get(f"/api/registrations/{reg_id}/").status_code, 404)
        self.assertEqual(self.client.post(f"/api/registrations/{reg_id}/cancel/").status_code, 404)

    def test_cannot_register_for_past_event(self):
        past = make_event(self.organizer, days=-2, title="Past")
        self.client.force_authenticate(self.alice)
        self.assertEqual(self.client.post(f"/api/events/{past.id}/register/").status_code, 400)

    def test_organizer_attendee_list(self):
        self.client.force_authenticate(self.alice)
        self.client.post(self.url())
        url = f"/api/events/{self.event.id}/registrations/"
        self.assertEqual(self.client.get(url).status_code, 403)
        self.client.force_authenticate(self.organizer)
        r = self.client.get(url)
        self.assertEqual(r.status_code, 200)
        self.assertEqual(len(r.data), 1)
