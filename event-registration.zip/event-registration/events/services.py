"""Business rules for registering / cancelling, kept out of the views."""
from django.db import transaction
from django.utils import timezone
from rest_framework.exceptions import ValidationError

from .models import Event, Registration


def register_user(user, event_id, phone="", notes=""):
    """Register `user` for an event. Safe against two people grabbing the last seat."""
    with transaction.atomic():
        # Locks the event row on PostgreSQL so capacity checks can't race.
        event = Event.objects.select_for_update().get(pk=event_id)

        if not event.is_published:
            raise ValidationError("This event is not open for registration.")
        if event.start_time <= timezone.now():
            raise ValidationError("This event has already started.")

        existing = Registration.objects.filter(user=user, event=event).first()
        if existing and existing.status == Registration.Status.REGISTERED:
            raise ValidationError("You are already registered for this event.")

        if event.registered_count >= event.capacity:
            raise ValidationError("Sorry, this event is full.")

        if existing:  # re-register after an earlier cancellation
            existing.status = Registration.Status.REGISTERED
            existing.cancelled_at = None
            existing.phone, existing.notes = phone, notes
            existing.save()
            return existing

        return Registration.objects.create(user=user, event=event, phone=phone, notes=notes)


def cancel_registration(registration):
    if registration.status == Registration.Status.CANCELLED:
        raise ValidationError("This registration is already cancelled.")
    registration.status = Registration.Status.CANCELLED
    registration.cancelled_at = timezone.now()
    registration.save(update_fields=["status", "cancelled_at"])
    return registration
