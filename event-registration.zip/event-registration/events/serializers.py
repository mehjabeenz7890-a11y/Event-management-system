from django.contrib.auth import get_user_model
from django.contrib.auth.password_validation import validate_password
from rest_framework import serializers

from .models import Event, Registration

User = get_user_model()


class UserRegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, style={"input_type": "password"})

    class Meta:
        model = User
        fields = ["id", "username", "email", "password"]

    def validate(self, attrs):
        candidate = User(username=attrs.get("username", ""), email=attrs.get("email", ""))
        validate_password(attrs["password"], candidate)
        return attrs

    def create(self, validated_data):
        return User.objects.create_user(**validated_data)


class EventSerializer(serializers.ModelSerializer):
    organizer = serializers.StringRelatedField(read_only=True)
    registered_count = serializers.SerializerMethodField()
    seats_left = serializers.SerializerMethodField()
    is_registered = serializers.SerializerMethodField()

    class Meta:
        model = Event
        fields = [
            "id", "title", "description", "location", "start_time", "end_time",
            "capacity", "is_published", "organizer", "registered_count", "seats_left",
            "is_registered", "created_at",
        ]
        read_only_fields = ["created_at"]

    def _count(self, obj):
        # Use the annotated value from the queryset when available (avoids N+1 queries).
        value = getattr(obj, "annotated_registered_count", None)
        return value if value is not None else obj.registered_count

    def get_registered_count(self, obj):
        return self._count(obj)

    def get_seats_left(self, obj):
        return max(obj.capacity - self._count(obj), 0)

    def get_is_registered(self, obj):
        request = self.context.get("request")
        if not request or not request.user.is_authenticated:
            return False
        return obj.registrations.filter(
            user=request.user, status=Registration.Status.REGISTERED
        ).exists()

    def validate(self, attrs):
        start = attrs.get("start_time", getattr(self.instance, "start_time", None))
        end = attrs.get("end_time", getattr(self.instance, "end_time", None))
        if start and end and end <= start:
            raise serializers.ValidationError({"end_time": "End time must be after start time."})
        capacity = attrs.get("capacity")
        if self.instance and capacity is not None and capacity < self.instance.registered_count:
            raise serializers.ValidationError(
                {"capacity": "Capacity can't be lower than the current number of registrations."}
            )
        return attrs


class EventBriefSerializer(serializers.ModelSerializer):
    class Meta:
        model = Event
        fields = ["id", "title", "location", "start_time", "end_time"]


class RegistrationSerializer(serializers.ModelSerializer):
    event = EventBriefSerializer(read_only=True)
    user = serializers.StringRelatedField(read_only=True)

    class Meta:
        model = Registration
        fields = ["id", "event", "user", "status", "phone", "notes", "created_at", "cancelled_at"]


class RegistrationFormSerializer(serializers.Serializer):
    """Fields a user fills in when registering for an event."""
    phone = serializers.CharField(max_length=30, required=False, allow_blank=True)
    notes = serializers.CharField(required=False, allow_blank=True)
