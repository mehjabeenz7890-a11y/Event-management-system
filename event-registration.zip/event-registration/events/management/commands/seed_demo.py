from datetime import timedelta

from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand
from django.utils import timezone

from events.models import Event


class Command(BaseCommand):
    help = "Create a demo organizer (admin / admin12345) and a few sample events."

    def handle(self, *args, **options):
        User = get_user_model()
        admin, created = User.objects.get_or_create(
            username="admin", defaults={"email": "admin@example.com", "is_staff": True, "is_superuser": True}
        )
        if created:
            admin.set_password("admin12345")
            admin.save()
        now = timezone.now()
        samples = [
            ("Python Meetup", "Lightning talks and networking.", "Community Hall, Room 2", 7, 50),
            ("Intro to Django Workshop", "Hands-on build of a small app.", "Tech Hub", 14, 20),
            ("Product Design Night", "Critique session and pizza.", "Studio 5", 21, 2),
        ]
        for title, desc, loc, days, cap in samples:
            Event.objects.get_or_create(
                title=title,
                defaults=dict(description=desc, location=loc, capacity=cap, organizer=admin,
                              start_time=now + timedelta(days=days),
                              end_time=now + timedelta(days=days, hours=3)),
            )
        self.stdout.write(self.style.SUCCESS("Demo data ready. Admin login: admin / admin12345"))
