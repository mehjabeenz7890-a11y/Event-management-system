from django.contrib.auth import get_user_model
from django.db.models import Count, Q
from django.shortcuts import get_object_or_404
from django.utils import timezone
from rest_framework import generics, permissions, status, viewsets
from rest_framework.authtoken.models import Token
from rest_framework.decorators import action
from rest_framework.response import Response

from .models import Event, Registration
from .permissions import IsOrganizerOrReadOnly
from .serializers import (
    EventSerializer, RegistrationFormSerializer, RegistrationSerializer, UserRegisterSerializer,
)
from .services import cancel_registration, register_user

User = get_user_model()


class SignupView(generics.CreateAPIView):
    """POST /api/auth/signup/ -> creates a user and returns an auth token."""
    serializer_class = UserRegisterSerializer
    permission_classes = [permissions.AllowAny]

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()
        token, _ = Token.objects.get_or_create(user=user)
        return Response(
            {"user": serializer.data, "token": token.key}, status=status.HTTP_201_CREATED
        )


class EventViewSet(viewsets.ModelViewSet):
    serializer_class = EventSerializer
    permission_classes = [IsOrganizerOrReadOnly]

    def get_queryset(self):
        qs = Event.objects.select_related("organizer").annotate(
            annotated_registered_count=Count(
                "registrations", filter=Q(registrations__status=Registration.Status.REGISTERED)
            )
        )
        qs = qs.order_by("start_time", "id")
        user = self.request.user
        if user.is_authenticated and user.is_staff:
            qs = qs.filter(Q(is_published=True) | Q(organizer=user))
        else:
            qs = qs.filter(is_published=True)

        params = self.request.query_params
        if params.get("upcoming") in ("1", "true", "True"):
            qs = qs.filter(start_time__gte=timezone.now())
        if search := params.get("search"):
            qs = qs.filter(Q(title__icontains=search) | Q(location__icontains=search))
        return qs

    def perform_create(self, serializer):
        serializer.save(organizer=self.request.user)

    @action(detail=True, methods=["post"], url_path="register")
    def register(self, request, pk=None):
        """POST /api/events/<id>/register/  body: {phone?, notes?}"""
        event = self.get_object()
        form = RegistrationFormSerializer(data=request.data)
        form.is_valid(raise_exception=True)
        registration = register_user(request.user, event.pk, **form.validated_data)
        return Response(RegistrationSerializer(registration).data, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=["get"], url_path="registrations",
            permission_classes=[permissions.IsAuthenticated])
    def registrations(self, request, pk=None):
        """GET /api/events/<id>/registrations/  (organizer of the event only)"""
        event = self.get_object()
        if not (request.user.is_superuser or event.organizer_id == request.user.id):
            return Response({"detail": "Only the organizer can view attendees."},
                            status=status.HTTP_403_FORBIDDEN)
        regs = event.registrations.select_related("user", "event")
        return Response(RegistrationSerializer(regs, many=True).data)


class RegistrationViewSet(viewsets.ReadOnlyModelViewSet):
    """A user's own registrations: list, detail, cancel."""
    serializer_class = RegistrationSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        qs = Registration.objects.filter(user=self.request.user).select_related("event", "user")
        if st := self.request.query_params.get("status"):
            qs = qs.filter(status=st)
        return qs

    @action(detail=True, methods=["post"], url_path="cancel")
    def cancel(self, request, pk=None):
        registration = get_object_or_404(self.get_queryset(), pk=pk)
        cancel_registration(registration)
        return Response(self.get_serializer(registration).data)

    def destroy(self, request, pk=None):  # DELETE is an alias for cancel (history is kept)
        return self.cancel(request, pk=pk)

    # allow DELETE on the detail route
    http_method_names = ["get", "post", "delete", "head", "options"]
