import csv

from django.contrib import admin
from django.http import HttpResponse

from .models import Event, Registration


class RegistrationInline(admin.TabularInline):
    model = Registration
    extra = 0
    readonly_fields = ["created_at", "cancelled_at"]


@admin.register(Event)
class EventAdmin(admin.ModelAdmin):
    list_display = ["title", "start_time", "location", "capacity", "registered_count", "is_published", "organizer"]
    list_filter = ["is_published", "start_time"]
    search_fields = ["title", "location"]
    inlines = [RegistrationInline]

    def save_model(self, request, obj, form, change):
        if not change and not obj.organizer_id:
            obj.organizer = request.user
        super().save_model(request, obj, form, change)

    def get_form(self, request, obj=None, **kwargs):
        form = super().get_form(request, obj, **kwargs)
        if "organizer" in form.base_fields:
            form.base_fields["organizer"].initial = request.user
        return form


@admin.action(description="Export selected registrations to CSV")
def export_csv(modeladmin, request, queryset):
    response = HttpResponse(content_type="text/csv")
    response["Content-Disposition"] = 'attachment; filename="registrations.csv"'
    writer = csv.writer(response)
    writer.writerow(["event", "username", "email", "phone", "status", "registered_at"])
    for r in queryset.select_related("user", "event"):
        writer.writerow([r.event.title, r.user.username, r.user.email, r.phone, r.status, r.created_at])
    return response


@admin.register(Registration)
class RegistrationAdmin(admin.ModelAdmin):
    list_display = ["user", "event", "status", "created_at"]
    list_filter = ["status", "event"]
    search_fields = ["user__username", "user__email", "event__title"]
    actions = [export_csv]
