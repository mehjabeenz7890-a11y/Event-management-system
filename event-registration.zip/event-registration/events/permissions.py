from rest_framework import permissions


class IsOrganizerOrReadOnly(permissions.BasePermission):
    """Anyone can read. Only staff (organizers) can create. Only the owner can edit/delete."""

    def has_permission(self, request, view):
        if request.method in permissions.SAFE_METHODS:
            return True
        if view.action == "register":  # any logged-in user may register
            return bool(request.user and request.user.is_authenticated)
        return bool(request.user and request.user.is_authenticated and request.user.is_staff)

    def has_object_permission(self, request, view, obj):
        if request.method in permissions.SAFE_METHODS or view.action == "register":
            return True
        return obj.organizer_id == request.user.id or request.user.is_superuser
